#!/bin/bash
args=("$@")

function goto
{
label=$1
cmd=$(sed -n "/$label:/{:a;n;p;ba};" $0 | grep -v ':$')
eval "$cmd"
exit
}

#@echo off
title batch script for FROG-kb Batch Likelihood Computation Tool
echo FROG-kb Batch Likelihood Computation Tool

DEL $0\..\input\ind\* /f /q
DEL $0\..\input\indGenotype\* /f /q
DEL $0\..\output\*.txt /f /q
sleep 
java -jar FROGAncestryCalc.jar
sleep 
DEL $0\..\input\ind\* /f /q
DEL $0\..\input\indGenotype\* /f /q